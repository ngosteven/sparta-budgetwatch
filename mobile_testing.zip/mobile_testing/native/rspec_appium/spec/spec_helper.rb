require 'pry'
require 'appium_lib'

RSpec.configure do |config|
  config.formatter = :documentation
end

def opts
  	{
    	caps: {
     		platformName: "Android",
     		deviceName: "emulator-5556",
     		app: "/Users/tech-a47/Engr7/mobiletesting/budgetwatch.apk"
    	}
 	}
end
