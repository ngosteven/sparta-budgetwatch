class BudgetPage

	BUDGET_PAGE = 'android:id/navigationBarBackground'
	BUDGET_ADD_NEW = 'protect.budgetwatch:id/action_add'
	BUDGET_NAME_TEXT_FIELD = 'protect.budgetwatch:id/budgetNameEdit'
	BUDGET_VALUE_TEXT_FIELD = 'protect.budgetwatch:id/valueEdit'
	BUDGET_SAVE_BTN = 'protect.budgetwatch:id/action_save'
	BUDGET_NAME_LABEL = 'protect.budgetwatch:id/budgetName'

	def initialize(driver)
		@driver = driver
	end

	def check_budget_page_displayed?
		@driver.find_element(:id, BUDGET_PAGE).enabled?	
	end

	def click_budget_new
		@driver.find_element(:id, BUDGET_ADD_NEW).click
	end

	def input_budget_name(name)
		@driver.find_element(:id, BUDGET_NAME_TEXT_FIELD).send_keys(name)
	end

	def input_budget_value(value)
		@driver.find_element(:id, BUDGET_VALUE_TEXT_FIELD).send_keys(value)
	end

	def click_budget_save
		@driver.find_element(:id, BUDGET_SAVE_BTN).click
	end

	def list_budget_name
		@driver.find_element(:id, BUDGET_NAME_LABEL).text
	end
end