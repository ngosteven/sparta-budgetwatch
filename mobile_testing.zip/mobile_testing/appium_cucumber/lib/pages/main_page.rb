class MainPage

	HOME_PAGE = 'android:id/navigationBarBackground'
	BUDGET_BTN = 'protect.budgetwatch:id/menu'

	def initialize(driver)
		@driver = driver
	end

	def check_homepage_displayed?
		@driver.find_element(:id, HOME_PAGE).enabled?
	end

	def click_budget_button
		@driver.find_element(:id, BUDGET_BTN).click
	end
end