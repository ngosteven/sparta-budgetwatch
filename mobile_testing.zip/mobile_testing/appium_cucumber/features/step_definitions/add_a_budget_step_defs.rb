Given("I can open the app") do
	mainpage.check_homepage_displayed?
end

When("click on budget") do
  	mainpage.click_budget_button
end

Then("the budget page opens") do
  	expect(budgetpage.check_budget_page_displayed?).to be true
end

When("I enter a budget") do
  	mainpage.click_budget_button
  	budgetpage.click_budget_new
  	budgetpage.input_budget_name('Steven')
  	budgetpage.input_budget_value(3)
end

When("save the budget") do
  	budgetpage.click_budget_save
end

Then("the budget is saved") do
  	expect(budgetpage.list_budget_name).to eq 'Steven'
end

Then("can be seen on the homepage") do
  	expect(budgetpage.check_budget_page_displayed?).to be true
end