require 'pry'
require 'cucumber'
require 'appium_lib'
require_relative '../../lib/budget_app'

def opts
  	{
    	caps: {
     		deviceName: "emulator-5556",
     		platformName: "Android",
     		app: "/Users/tech-a47/Engr7/mobiletesting/budgetwatch.apk"
    	}
 	}
end

Appium::Driver.new(opts, true)

World(BudgetApp)
